from pyrogram import Client, filters

from Data.config import api_id, api_hash

app = Client(name="my_account", api_id=api_id, api_hash=api_hash)


@app.on_message(filters.me)
def echo(client, message):
    message.reply_text(message.text)


app.run()
